const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder,
  MessageFlags, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle
} = require('discord.js');
const config = require('../../config.js');

const CATEGORIES = {
  'Information':  { emoji: '<:emoji_1:1504190199121313822>' },
  'AntiNuke':     { emoji: '<:emoji_2:1504190435000582374>' },
  'Economy':      { emoji: '<:emoji_3:1504191236192473329>' },
  'Reaction':     { emoji: '<:emoji_4:1504191475687362710>' },
  'Verification': { emoji: '<:idk:1504192001837629491>' },
  'Moderation':   { emoji: '<:mod:1504192145404198965>' },
  'Giveaway':     { emoji: '<:gwy:1504200216746655915>' },
  'Ticket':       { emoji: '<:shuffle:1504199644555514049>' },
  'Music':        { emoji: '<:emoji_41:1504446135698198639>' },
  'Config':       { emoji: '<:odo:1504193914884587521>' },
  'Utility':      { emoji: '<:utif:1504194079347576862>' },
  'Owner':        { emoji: '<:dve:1504194307685617874>' },
  'Favourite':    { emoji: '<:fav:1504194445942329466>' },
};

function getCommands(client) {
  const cmds = {};
  for (const [, cmd] of client.commands) {
    const cat = cmd.category || 'Uncategorized';
    if (!cmds[cat]) cmds[cat] = [];
    cmds[cat].push(cmd);
  }
  return cmds;
}

module.exports = {
  name: 'help',
  aliases: ['h', 'commands', 'cmds', 'menu'],
  category: 'Information',
  description: `Browse all ${config.botName} commands with an interactive menu`,
  cooldown: 5,
  slashOptions: [
    { name: 'category', description: 'Jump directly to a category', type: 3, required: false }
  ],

  async slashExecute(interaction, client) {
    await interaction.deferReply();
    const catArg = interaction.options.getString('category');
    return this._run(
      { author: interaction.user, editReply: (o) => interaction.editReply(o), fetchReply: () => interaction.fetchReply() },
      catArg, client, true
    );
  },

  async execute(message, args, client) {
    return this._run(message, args[0], client, false);
  },

  async _run(ctx, catArg, client, isSlash) {
    const author = ctx.author || ctx.user;
    const allCmds = getCommands(client);
    const CAT_ORDER = Object.keys(CATEGORIES);
    const availableCats = [
      ...CAT_ORDER.filter(c => allCmds[c]?.length),
      ...Object.keys(allCmds).filter(c => !CAT_ORDER.includes(c) && allCmds[c]?.length)
    ];

    const buildCatSelect = (placeholder) => new StringSelectMenuBuilder()
      .setCustomId('help_cat_select')
      .setPlaceholder(placeholder || 'Select a category...')
      .addOptions(availableCats.slice(0, 25).map(c => ({
        label: c,
        value: c,
        emoji: CATEGORIES[c]?.emoji || '📁'
      })));

    const buildMain = () => {
      const totalCmds = Object.values(allCmds).reduce((a, b) => a + b.length, 0);
      const catList = availableCats.map(cat => {
        const em = CATEGORIES[cat]?.emoji || '📁';
        return `${em} ${cat}`;
      }).join('\n');

      return new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `### ${client.config.botName} — Command Dashboard\n` +
          `Prefix: \`${client.config?.prefix || '!'}\` · Commands: \`${totalCmds}\` · Categories: \`${availableCats.length}\`\n\n` +
          `${catList}\n\n` +
          `-# Use the menu below to explore categories.`
        ))
        .addSeparatorComponents(new SeparatorBuilder())
        .addActionRowComponents(new ActionRowBuilder().addComponents(buildCatSelect('Select a category...')));
    };

    const buildCategory = (cat) => {
      const cmds = allCmds[cat] || [];
      const em = CATEGORIES[cat]?.emoji || '📁';
      const prefix = client.config?.prefix || '!';

      const cmdNames = cmds.map(c => `\`${prefix}${c.name}\``).join('\n');

      const backBtn = new ButtonBuilder()
        .setCustomId('help_back')
        .setLabel('Return Home')
        .setStyle(ButtonStyle.Secondary);

      const infoBtn = new ButtonBuilder()
        .setCustomId(`help_cmd_info:${cat}`)
        .setLabel('View Command Info')
        .setStyle(ButtonStyle.Primary);

      return new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `### ${em} ${cat.toUpperCase()}\n` +
          `${cmds.length} Commands\n\n` +
          `${cmdNames || 'No commands yet.'}\n\n` +
          `-# Tap "View Command Info" to see what a command does.`
        ))
        .addSeparatorComponents(new SeparatorBuilder())
        .addActionRowComponents(new ActionRowBuilder().addComponents(buildCatSelect(`Viewing: ${cat}`)))
        .addActionRowComponents(new ActionRowBuilder().addComponents(backBtn, infoBtn));
    };

    const buildCmdSelect = (cat) => {
      const cmds = allCmds[cat] || [];
      const em = CATEGORIES[cat]?.emoji || '📁';
      const prefix = client.config?.prefix || '!';

      const cmdSelect = new StringSelectMenuBuilder()
        .setCustomId(`help_cmd_select:${cat}`)
        .setPlaceholder('Choose a command to see its description...')
        .addOptions(cmds.slice(0, 25).map(c => ({
          label: `${prefix}${c.name}`,
          value: c.name,
          description: (c.description || 'No description').slice(0, 100),
        })));

      const backBtn = new ButtonBuilder()
        .setCustomId(`help_cat_back:${cat}`)
        .setLabel('Back to List')
        .setStyle(ButtonStyle.Secondary);

      return new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `### ${em} ${cat} — Choose a Command\n` +
          `-# Select a command from the menu below to view its description.`
        ))
        .addSeparatorComponents(new SeparatorBuilder())
        .addActionRowComponents(new ActionRowBuilder().addComponents(cmdSelect))
        .addActionRowComponents(new ActionRowBuilder().addComponents(backBtn));
    };

    const buildCmdDetail = (cat, cmdName) => {
      const cmds = allCmds[cat] || [];
      const em = CATEGORIES[cat]?.emoji || '📁';
      const prefix = client.config?.prefix || '!';
      const cmd = cmds.find(c => c.name === cmdName);
      if (!cmd) return buildCategory(cat);

      const aliases = cmd.aliases?.length
        ? `\n**Aliases:** ${(Array.isArray(cmd.aliases) ? cmd.aliases : [cmd.aliases]).map(a => `\`${prefix}${a}\``).join(', ')}`
        : '';
      const usage = cmd.usage ? `\n**Usage:** \`${prefix}${cmd.name} ${cmd.usage}\`` : '';
      const cooldown = cmd.cooldown ? `\n**Cooldown:** \`${cmd.cooldown}s\`` : '';

      const backBtn = new ButtonBuilder()
        .setCustomId(`help_cmd_info:${cat}`)
        .setLabel('Back to Select')
        .setStyle(ButtonStyle.Secondary);

      const catBtn = new ButtonBuilder()
        .setCustomId(`help_cat_back:${cat}`)
        .setLabel('Back to List')
        .setStyle(ButtonStyle.Secondary);

      return new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `### ${em} \`${prefix}${cmd.name}\`\n` +
          `**Description:** ${cmd.description || 'No description provided.'}` +
          `${aliases}${usage}${cooldown}\n\n` +
          `-# Category: ${cat}`
        ))
        .addSeparatorComponents(new SeparatorBuilder())
        .addActionRowComponents(new ActionRowBuilder().addComponents(backBtn, catBtn));
    };

    const initial = (() => {
      if (catArg) {
        const match = availableCats.find(c => c.toLowerCase() === catArg.toLowerCase());
        return match ? buildCategory(match) : buildMain();
      }
      return buildMain();
    })();

    const opts = { components: [initial], flags: MessageFlags.IsComponentsV2 };
    let sent;
    if (isSlash) {
      await ctx.editReply(opts);
      sent = await ctx.fetchReply().catch(() => null);
    } else {
      sent = await ctx.reply(opts);
    }
    if (!sent) return;

    const collector = sent.createMessageComponentCollector({ time: 180000 });
    collector.on('collect', async (i) => {
      if (i.user.id !== author.id) return i.reply({ content: '❌ This menu is not yours.', flags: 64 });

      if (i.customId === 'help_cat_select') {
        return i.update({ components: [buildCategory(i.values[0])], flags: MessageFlags.IsComponentsV2 });
      }
      if (i.customId === 'help_back') {
        return i.update({ components: [buildMain()], flags: MessageFlags.IsComponentsV2 });
      }
      if (i.customId.startsWith('help_cmd_info:')) {
        const cat = i.customId.split(':')[1];
        return i.update({ components: [buildCmdSelect(cat)], flags: MessageFlags.IsComponentsV2 });
      }
      if (i.customId.startsWith('help_cmd_select:')) {
        const cat = i.customId.split(':')[1];
        return i.update({ components: [buildCmdDetail(cat, i.values[0])], flags: MessageFlags.IsComponentsV2 });
      }
      if (i.customId.startsWith('help_cat_back:')) {
        const cat = i.customId.split(':')[1];
        return i.update({ components: [buildCategory(cat)], flags: MessageFlags.IsComponentsV2 });
      }
    });

    collector.on('end', () => {
      const expired = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          `### ${client.config.botName} — Command Dashboard\n*This menu expired. Run \`help\` to open a new one.*\n-# Developed by ${client.config.devName}`
        ));
      sent.edit({ components: [expired], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    });
  }
};
